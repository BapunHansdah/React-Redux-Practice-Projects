import react from 'react'
import '../css/header.css'
function header(){
   return(
     <>
       <div className="header">
          <div className="logo"><div>logo</div></div>
          <div className="nav">
             <div className="nav1">nav</div>
             <div className="nav2">nav</div>
             <div className="nav2">nav</div>
             <div className="nav2">nav</div>
          </div>
       </div>
     </>
   )
}

export default header;