import react from 'react'

function searchedList(){
   return(
     <>
       <div>Search List</div>
     </>
   )
}

export default searchedList;